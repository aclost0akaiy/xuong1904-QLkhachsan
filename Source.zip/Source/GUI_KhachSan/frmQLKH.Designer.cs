﻿namespace GUI_KhachSan
{
    partial class frmQLKH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            txtKH = new TextBox();
            txtHT = new TextBox();
            txtDC = new TextBox();
            comGT = new ComboBox();
            txtCCCD = new TextBox();
            txtSDT = new TextBox();
            imeNT = new DateTimePicker();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            rbhoatdong = new RadioButton();
            rbkhonghoatdong = new RadioButton();
            txtghichu = new TextBox();
            label10 = new Label();
            butthem = new Button();
            ButXoa = new Button();
            butsua = new Button();
            butLM = new Button();
            buttTK = new Button();
            textBox7 = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(508, 75);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(696, 474);
            dataGridView1.TabIndex = 0;
            // 
            // txtKH
            // 
            txtKH.Location = new Point(136, 75);
            txtKH.Name = "txtKH";
            txtKH.Size = new Size(337, 27);
            txtKH.TabIndex = 1;
            // 
            // txtHT
            // 
            txtHT.Location = new Point(136, 123);
            txtHT.Name = "txtHT";
            txtHT.Size = new Size(337, 27);
            txtHT.TabIndex = 2;
            // 
            // txtDC
            // 
            txtDC.Location = new Point(136, 171);
            txtDC.Name = "txtDC";
            txtDC.Size = new Size(337, 27);
            txtDC.TabIndex = 3;
            // 
            // comGT
            // 
            comGT.FormattingEnabled = true;
            comGT.Location = new Point(136, 221);
            comGT.Name = "comGT";
            comGT.Size = new Size(337, 28);
            comGT.TabIndex = 4;
            // 
            // txtCCCD
            // 
            txtCCCD.Location = new Point(136, 310);
            txtCCCD.Name = "txtCCCD";
            txtCCCD.Size = new Size(337, 27);
            txtCCCD.TabIndex = 5;
            // 
            // txtSDT
            // 
            txtSDT.Location = new Point(136, 267);
            txtSDT.Name = "txtSDT";
            txtSDT.Size = new Size(337, 27);
            txtSDT.TabIndex = 6;
            // 
            // imeNT
            // 
            imeNT.Location = new Point(136, 359);
            imeNT.Name = "imeNT";
            imeNT.Size = new Size(250, 27);
            imeNT.TabIndex = 7;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 82);
            label1.Name = "label1";
            label1.Size = new Size(103, 20);
            label1.TabIndex = 8;
            label1.Text = "khách hàng ID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 130);
            label2.Name = "label2";
            label2.Size = new Size(54, 20);
            label2.TabIndex = 9;
            label2.Text = "Họ tên";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 178);
            label3.Name = "label3";
            label3.Size = new Size(55, 20);
            label3.TabIndex = 10;
            label3.Text = "Dịa chỉ";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 229);
            label4.Name = "label4";
            label4.Size = new Size(65, 20);
            label4.TabIndex = 11;
            label4.Text = "Giới tính";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 274);
            label5.Name = "label5";
            label5.Size = new Size(35, 20);
            label5.TabIndex = 12;
            label5.Text = "SDT";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(12, 317);
            label6.Name = "label6";
            label6.Size = new Size(47, 20);
            label6.TabIndex = 13;
            label6.Text = "CCCD";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(12, 364);
            label7.Name = "label7";
            label7.Size = new Size(70, 40);
            label7.TabIndex = 14;
            label7.Text = "Ngày tạo\r\n\r\n";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(12, 413);
            label8.Name = "label8";
            label8.Size = new Size(75, 20);
            label8.TabIndex = 15;
            label8.Text = "Trạng thái";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(12, 458);
            label9.Name = "label9";
            label9.Size = new Size(57, 20);
            label9.TabIndex = 16;
            label9.Text = "ghi chú";
            // 
            // rbhoatdong
            // 
            rbhoatdong.AutoSize = true;
            rbhoatdong.Location = new Point(136, 411);
            rbhoatdong.Name = "rbhoatdong";
            rbhoatdong.Size = new Size(102, 24);
            rbhoatdong.TabIndex = 17;
            rbhoatdong.TabStop = true;
            rbhoatdong.Text = "Hoạt động\r\n";
            rbhoatdong.UseVisualStyleBackColor = true;
            // 
            // rbkhonghoatdong
            // 
            rbkhonghoatdong.AutoSize = true;
            rbkhonghoatdong.Location = new Point(356, 413);
            rbkhonghoatdong.Name = "rbkhonghoatdong";
            rbkhonghoatdong.Size = new Size(146, 24);
            rbkhonghoatdong.TabIndex = 18;
            rbkhonghoatdong.TabStop = true;
            rbkhonghoatdong.Text = "Không hoạt động";
            rbkhonghoatdong.UseVisualStyleBackColor = true;
            // 
            // txtghichu
            // 
            txtghichu.Location = new Point(136, 455);
            txtghichu.Name = "txtghichu";
            txtghichu.Size = new Size(337, 27);
            txtghichu.TabIndex = 19;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.Location = new Point(404, 9);
            label10.Name = "label10";
            label10.Size = new Size(337, 46);
            label10.TabIndex = 20;
            label10.Text = "Quản lý Khách hàng";
            // 
            // butthem
            // 
            butthem.Location = new Point(12, 507);
            butthem.Name = "butthem";
            butthem.Size = new Size(118, 42);
            butthem.TabIndex = 21;
            butthem.Text = "Thêm";
            butthem.UseVisualStyleBackColor = true;
            // 
            // ButXoa
            // 
            ButXoa.Location = new Point(136, 507);
            ButXoa.Name = "ButXoa";
            ButXoa.Size = new Size(118, 42);
            ButXoa.TabIndex = 22;
            ButXoa.Text = "Xóa";
            ButXoa.UseVisualStyleBackColor = true;
            // 
            // butsua
            // 
            butsua.Location = new Point(260, 507);
            butsua.Name = "butsua";
            butsua.Size = new Size(118, 42);
            butsua.TabIndex = 23;
            butsua.Text = "Sửa";
            butsua.UseVisualStyleBackColor = true;
            // 
            // butLM
            // 
            butLM.Location = new Point(384, 507);
            butLM.Name = "butLM";
            butLM.Size = new Size(118, 42);
            butLM.TabIndex = 24;
            butLM.Text = "làm mới";
            butLM.UseVisualStyleBackColor = true;
            butLM.Click += button4_Click;
            // 
            // buttTK
            // 
            buttTK.Location = new Point(1110, 42);
            buttTK.Name = "buttTK";
            buttTK.Size = new Size(94, 29);
            buttTK.TabIndex = 25;
            buttTK.Text = "tìm kiếm";
            buttTK.UseVisualStyleBackColor = true;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(747, 42);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(351, 27);
            textBox7.TabIndex = 26;
            // 
            // frmQLKH
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.AntiqueWhite;
            ClientSize = new Size(1206, 554);
            Controls.Add(textBox7);
            Controls.Add(buttTK);
            Controls.Add(butLM);
            Controls.Add(butsua);
            Controls.Add(ButXoa);
            Controls.Add(butthem);
            Controls.Add(label10);
            Controls.Add(txtghichu);
            Controls.Add(rbkhonghoatdong);
            Controls.Add(rbhoatdong);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(imeNT);
            Controls.Add(txtSDT);
            Controls.Add(txtCCCD);
            Controls.Add(comGT);
            Controls.Add(txtDC);
            Controls.Add(txtHT);
            Controls.Add(txtKH);
            Controls.Add(dataGridView1);
            Name = "frmQLKH";
            Text = "frmQLKH";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private TextBox txtKH;
        private TextBox txtHT;
        private TextBox txtDC;
        private ComboBox comGT;
        private TextBox txtCCCD;
        private TextBox txtSDT;
        private DateTimePicker imeNT;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private RadioButton rbhoatdong;
        private RadioButton rbkhonghoatdong;
        private TextBox txtghichu;
        private Label label10;
        private Button butthem;
        private Button ButXoa;
        private Button butsua;
        private Button butLM;
        private Button buttTK;
        private TextBox textBox7;
    }
}